import Figures.Figure;
import Figures.Hero.Hero;
import Figures.Hero.HeroType;
import Figures.Monster.Monster;
import Figures.Party;
import Items.Inventory;
import Items.Item;
import Items.Potion.Potion;
import Items.Weapon;

import java.util.List;
import java.util.Map;

import static Figures.Monster.Monster.assembleMonsterBattleParty;
import static UI.UserInputs.showMenuAndGetUserAnswer;

public class Testing {

    public static void main(String[] args){
        Hero h = Hero.getAllHeroOptions().get(0);
        Party<Hero> heroes = new Party<>(3);
        heroes.addMember(h);
        Party<Monster> monsters = assembleMonsterBattleParty(heroes);
        System.out.println(monsters.getMembersNamesMap());


    }
}
