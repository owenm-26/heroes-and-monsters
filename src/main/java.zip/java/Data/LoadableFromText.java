package Data;

import java.util.Map;

public interface LoadableFromText {
    void loadFromMap(Map<String, String> values);


}
