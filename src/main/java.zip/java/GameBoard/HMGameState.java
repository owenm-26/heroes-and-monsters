package GameBoard;

public enum HMGameState {
    EXPLORING(),
    MARKET(),
    BATTLING();
}
