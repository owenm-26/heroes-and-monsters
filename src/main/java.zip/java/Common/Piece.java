package Common;

public abstract class Piece {
}
