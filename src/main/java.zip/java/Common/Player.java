package Common;

public abstract class Player extends Piece{

}
