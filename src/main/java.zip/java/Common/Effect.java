package Common;

public abstract class Effect {

    protected String name;

    public String getName() {
        return name;
    }
}
