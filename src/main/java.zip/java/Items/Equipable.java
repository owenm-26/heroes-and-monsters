package Items;

public interface Equipable {

    public boolean isEquipable();
}
