package Figures;

public enum TraitType {
    STRENGTH(),
    DEXTERITY(),
    AGILITY();
}
